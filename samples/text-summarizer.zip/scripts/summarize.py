#!/usr/bin/env python3
"""Rút trích câu quan trọng bằng chấm điểm tần suất từ (frequency scoring).

Cách dùng:
    python3 summarize.py input.txt --sentences 5
"""
import argparse
import re
from collections import Counter


def split_sentences(text: str) -> list[str]:
    parts = re.split(r"(?<=[.!?])\s+", text.strip())
    return [p.strip() for p in parts if p.strip()]


def score_sentences(sentences: list[str]) -> dict[int, float]:
    words = re.findall(r"\w+", " ".join(sentences).lower())
    freq = Counter(words)
    scores: dict[int, float] = {}
    for i, sent in enumerate(sentences):
        tokens = re.findall(r"\w+", sent.lower())
        if not tokens:
            continue
        scores[i] = sum(freq[t] for t in tokens) / len(tokens)
    return scores


def summarize(text: str, top_n: int = 5) -> list[str]:
    sentences = split_sentences(text)
    scores = score_sentences(sentences)
    ranked = sorted(scores, key=scores.get, reverse=True)[:top_n]
    return [sentences[i] for i in sorted(ranked)]


def main() -> None:
    parser = argparse.ArgumentParser(description="Extractive text summarizer")
    parser.add_argument("input", help="Path to a .txt/.md file")
    parser.add_argument("--sentences", type=int, default=5)
    args = parser.parse_args()

    with open(args.input, encoding="utf-8") as fh:
        text = fh.read()

    for point in summarize(text, args.sentences):
        print(f"- {point}")


if __name__ == "__main__":
    main()
