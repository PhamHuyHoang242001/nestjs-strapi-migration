# Tóm tắt: {{title}}

## Ý chính
- {{point_1}}
- {{point_2}}
- {{point_3}}
- {{point_4}}
- {{point_5}}

## Abstract
{{abstract}}
