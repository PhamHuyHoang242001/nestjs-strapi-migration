---
name: text-summarizer
description: Summarize long text, articles, or documents into concise bullet points and a short abstract. Use when the user asks to summarize, condense, shorten, or extract key points from a block of text or a file.
metadata:
  version: 1.0.0
  author: eda-team
---

# Text Summarizer

Rút gọn văn bản dài thành các ý chính và một đoạn tóm tắt ngắn.

## Khi nào dùng

Kích hoạt skill này khi người dùng muốn:
- Tóm tắt một bài viết, tài liệu, hoặc đoạn văn dài.
- Rút trích các ý chính (key points) dưới dạng bullet.
- Cô đọng nội dung xuống một độ dài mục tiêu.

## Cách hoạt động

1. Nhận văn bản đầu vào (dán trực tiếp hoặc đường dẫn file `.txt`/`.md`).
2. Xác định độ dài mục tiêu: mặc định 5 bullet + 1 đoạn abstract ~3 câu.
3. Chạy `scripts/summarize.py` để tiền xử lý và chấm điểm câu.
4. Trình bày kết quả theo `assets/summary-template.md`.

## Ví dụ

Input: một bài viết 1000 từ về điện toán đám mây.

Output:
- 5 gạch đầu dòng nêu luận điểm chính.
- 1 đoạn abstract ngắn gọn.

## Tham khảo

- Quy tắc văn phong: `references/style-guide.md`.
- Mẫu trình bày: `assets/summary-template.md`.

## Ràng buộc

- Giữ nguyên ý nghĩa gốc, không thêm thông tin ngoài văn bản.
- Không vượt quá độ dài mục tiêu người dùng yêu cầu.
