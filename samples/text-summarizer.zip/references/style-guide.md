# Quy tắc văn phong khi tóm tắt

- Mỗi bullet là một ý trọn vẹn, không quá 20 từ.
- Ưu tiên động từ chủ động, bỏ từ đệm ("có thể", "về cơ bản").
- Giữ thuật ngữ gốc; không diễn giải sai nghĩa.
- Abstract 2–3 câu, nêu chủ đề + kết luận chính.
- Không thêm ý kiến cá nhân hay thông tin ngoài văn bản gốc.
